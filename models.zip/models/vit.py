# https://github.com/lucidrains/vit-pytorch/blob/main/vit_pytorch/vit_pytorch.py

import torch
import torch.nn.functional as F
from einops import rearrange
from torch import nn
from functools import partial
from itertools import repeat
from collections import OrderedDict
from einops import rearrange
from einops.layers.torch import Rearrange
import math
from pygcn.models import GCN
import numpy as np
# import cupy as cp
from models import mobilenet

from models import *
from tcn_mnist import TemporalConvNet


# from torch._six import container_abcs

# From PyTorch internals
def _ntuple(n):
    def parse(x):
        # if isinstance(x, container_abcs.Iterable):
        #     return x
        return tuple(repeat(x, n))

    return parse


to_2tuple = _ntuple(2)

MIN_NUM_PATCHES = 16


class Residual(nn.Module):
    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def forward(self, x, *args, **kwargs):
        return self.fn(x, *args, **kwargs) + x


class PreNorm(nn.Module):
    def __init__(self, dim, fn):
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        self.fn = fn

    def forward(self, x, *args, **kwargs):
        temp = self.norm(x)
        return self.fn(temp, *args, **kwargs)


# class PreForward(nn.Module):
#     def __init__(self, dim, hidden_dim, kernel_size, num_channels, dropout=0.):
#         super().__init__()
#         # self.net = nn.Sequential(
#         #     nn.Linear(dim, hidden_dim),
#         #     nn.GELU(),
#         #     nn.Dropout(dropout),
#         #     nn.Linear(hidden_dim, dim),
#         #     nn.Dropout(dropout)
#         # )
#         self.tcn = TemporalConvNet(dim, num_channels, hidden_dim, kernel_size, dropout)
#         # self.net = nn.Sequential(
#         #     nn.Linear(dim, hidden_dim),
#         #     nn.GELU(),
#         #     nn.Dropout(dropout),
#         # )
#
#     def forward(self, x):
#         r = self.tcn(x.permute(0, 2, 1)).permute(0, 2, 1)
#         # r = self.net(r)
#         return r


class FeedForward(nn.Module):
    def __init__(self, dim, hidden_dim, image_size, patch_size, kernel_size, dropout=0.):
        super().__init__()
        # self.net = nn.Sequential(
        #     nn.Linear(dim, hidden_dim),
        #     nn.GELU(),
        #     nn.Dropout(dropout),
        #     nn.Linear(hidden_dim, dim),
        #     nn.Dropout(dropout)
        # )
        self.net = nn.Identity()
    def forward(self, x):
        return self.net(x)


class Attention(nn.Module):
    def __init__(self,
                 dim,
                 image_size,
                 patch_size,
                 heads=8,
                 dropout=0,
                 qkv_bias=False,
                 attn_drop=0.,
                 proj_drop=0.,
                 method='dw_bn',
                 kernel_size=3,
                 stride_kv=1,
                 stride_q=1,
                 padding_kv=1,
                 padding_q=1,
                 with_cls_token=False
                 ):
        super().__init__()
        self.scale = dim ** -0.5

        # self.to_qkv = nn.Linear(dim, dim * 3, bias = False)
        # self.to_out = nn.Sequential(
        #     nn.Linear(dim, dim),
        #     nn.Dropout(dropout)
        # )

        self.stride_kv = stride_kv
        self.stride_q = stride_q
        self.dim = dim
        self.num_heads = heads
        self.scale = dim ** -0.5
        self.with_cls_token = with_cls_token
        self.x_to_one = nn.Linear(int(dim/self.num_heads), 1)

        dim_in = dim
        dim_out = dim
        self.conv_proj_q = self._build_projection(
            dim_in, heads, dim_out, image_size, patch_size, dropout, kernel_size, padding_q,
            stride_q, 'linear' if method == 'avg' else method
        )
        self.conv_proj_k = self._build_projection(
            dim_in, heads, dim_out, image_size, patch_size, dropout, kernel_size, padding_kv,
            stride_kv, method
        )
        self.conv_proj_v = self._build_projection(
            dim_in, heads, dim_out, image_size, patch_size, dropout, kernel_size, padding_kv,
            stride_kv, method
        )

        self.proj_q = nn.Linear(dim_in, dim_out, bias=qkv_bias)
        self.proj_k = nn.Linear(dim_in, dim_out, bias=qkv_bias)
        self.proj_v = nn.Linear(dim_in, dim_out, bias=qkv_bias)

        self.attn_drop = nn.Dropout(attn_drop)  #
        self.proj_drop = nn.Dropout(proj_drop)   #

    def _build_projection(self,
                          dim_in,
                          head_num,
                          dim_out,
                          image_size,
                          patch_size,
                          dropout,
                          kernel_size,
                          padding,
                          stride,
                          method):
        if method == 'dw_bn':
            proj = GCN(nfeat=dim_in,
                            head_num=head_num,
                            nhid=dim_out,
                            image_size=image_size,
                            patch_size=patch_size,
                            stride=2,
                            padding=1,  # using 2 when kernel_size = 4
                            kernel_size=kernel_size,  # kernel_size of GCN
                            nclass=dim_in,
                            dropout=dropout)
        elif method == 'avg':
            proj = nn.Sequential(OrderedDict([
                ('avg', nn.AvgPool2d(
                    kernel_size=kernel_size,
                    padding=padding,
                    stride=stride,
                    ceil_mode=True
                )),
                ('rearrage', Rearrange('b c h w -> b (h w) c')),
            ]))
        elif method == 'linear':
            proj = None
        else:
            raise ValueError('Unknown method ({})'.format(method))

        return proj

    def forward_conv_qk(self, x, h, w, rep_adj):
        if self.with_cls_token:
            cls_token, x = torch.split(x, [1, h * w], 1)

        if self.conv_proj_q is not None:
            q = self.conv_proj_q(x, rep_adj)
        else:
            q = rearrange(x, 'b c h w -> b (h w) c')

        if self.conv_proj_k is not None:
            k = self.conv_proj_k(x, rep_adj)
        else:
            k = rearrange(x, 'b c h w -> b (h w) c')

        return q, k

    def forward_conv_v(self, x, h, w, rep_adj):
        if self.with_cls_token:
            cls_token, x = torch.split(x, [1, h * w], 1)

        if self.conv_proj_v is not None:
            v = self.conv_proj_v(x, rep_adj)
        else:
            v = rearrange(x, 'b c h w -> b (h w) c')

        return v

    def forward(self, x, h, w, adj):
        x = rearrange(x, 'b t (h d) -> b h t d', h=self.num_heads)

        if (
                self.conv_proj_q is not None
                or self.conv_proj_k is not None
                or self.conv_proj_v is not None
        ):
            q, k = self.forward_conv_qk(x, h, w, adj)
        q = self.proj_q(rearrange(q, 'b h t d -> b t (h d)', h=self.num_heads))
        q = rearrange(q, 'b t (h d) -> b h t d', h=self.num_heads)

        k = self.proj_k(rearrange(k, 'b h t d -> b t (h d)', h=self.num_heads))
        k = rearrange(k, 'b t (h d) -> b h t d', h=self.num_heads)

        attn_score = torch.einsum('bhlk,bhtk->bhlt', [q, k]) * self.scale
        attn = F.softmax(attn_score, dim=-1)
        attn = self.attn_drop(attn)

        # rep_adj = torch.mul(adj, attn).cuda()
        # rep_adj = torch.einsum('bhlt,bhtv->bhlv', [attn, adj])
        rep_adj = attn

        # #  similarity
        # x4sim = rearrange(x, 'b h t d -> b t (h d)', h=self.num_heads)
        # repeat_x = x4sim.unsqueeze(2).to(device)
        # repeat_x_T = x4sim.unsqueeze(1).to(device)
        # similarity = 1 - torch.cosine_similarity(repeat_x, repeat_x_T, dim=-1)
        # similarity = similarity.expand(self.num_heads, -1, -1, -1).to(device)
        # similarity = similarity.permute(1, 0, 2, 3)
        # rep_adj = torch.mul(rep_adj, similarity).cuda()

        x4sim = x
        repeat_x = x4sim.unsqueeze(3).to(device)
        repeat_x_T = x4sim.unsqueeze(2).to(device)
        similarity = 1 - torch.cosine_similarity(repeat_x, repeat_x_T, dim=-1)
        similarity = torch.softmax(similarity, dim=3)
        rep_adj = torch.mul(rep_adj, similarity).cuda()

        pointer = self.x_to_one(x)
        pointer = torch.softmax(pointer, dim=2)
        pointer_b = torch.eye(pointer.size(2))
        pointer_c = pointer.expand(*pointer.squeeze().size(), pointer.size(2))
        pointer_diag = pointer_c * pointer_b.cuda()
        rep_adj = torch.matmul(rep_adj, pointer_diag)


        v = self.forward_conv_v(x, h, w, rep_adj)

        v = self.proj_v(rearrange(v, 'b h t d -> b t (h d)', h=self.num_heads))

        x = self.proj_drop(v)

        out = x

        return out


device = 'cuda' if torch.cuda.is_available() else 'cpu'


class ConvEmbed(nn.Module):
    """ Image to Conv Embedding

    """

    def __init__(self,
                 image_size,
                 patch_size,
                 kernel_size,
                 batch_size,
                 in_chans,
                 embed_dim,
                 stride,
                 padding,
                 norm_layer=None):
        super().__init__()
        # kernel_size = to_2tuple(kernel_size)
        # self.patch_size = patch_size

        # self.proj = ResNet50(embed_dim).to(device)
        # self.proj = MobileNet13()

        # self.proj = nn.Conv2d(
        #     in_chans, embed_dim,
        #     kernel_size=kernel_size,
        #     stride=stride,
        #     padding=padding
        # )

        self.proj = nn.Sequential(OrderedDict([
            ('conv1', nn.Conv2d(
                in_chans, int(embed_dim),
                kernel_size=kernel_size,
                stride=stride,
                padding=padding,
                # groups=in_chans
            )),
            # ('pooling', nn.AdaptiveMaxPool2d((int(image_size / patch_size), int(image_size / patch_size)))),
            ('bn', nn.BatchNorm2d(int(embed_dim))),
            ('relu', nn.GELU()),
            ('conv2', nn.Conv2d(
                int(embed_dim), int(embed_dim),
                kernel_size=kernel_size,
                stride=stride,
                padding=padding,
                groups=int(embed_dim)
            )),
            ('pooling', nn.AdaptiveMaxPool2d((int(image_size / patch_size/2), int(image_size / patch_size/2)))),
            ('bn', nn.BatchNorm2d(int(embed_dim))),
            ('relu', nn.GELU()),
        ]))

        # self.proj = nn.Sequential(OrderedDict([
        #     ('conv1', nn.Conv2d(
        #         in_chans, int(embed_dim),
        #         kernel_size=kernel_size,
        #         stride=stride,
        #         padding=padding,
        #         # groups=in_chans
        #     )),
        #     ('pooling', nn.AdaptiveMaxPool2d((int(image_size / patch_size / 4), int(image_size / patch_size / 4)))),
        #     ('bn', nn.BatchNorm2d(int(embed_dim))),
        #     ('relu', nn.GELU()),
        # ]))
        # self.norm = norm_layer(embed_dim) if norm_layer else None

    def forward(self, x):
        sp_features = self.proj(x).to(device)  # proj_conv  proj

        return sp_features


class Transformer(nn.Module):
    def __init__(self, dim, depth, heads, mlp_dim, dropout, image_size, patch_size, kernel_size, num_channels, batch_size, in_chans,
                 patch_stride, patch_padding, norm_layer=nn.LayerNorm):
        super().__init__()

        self.patch_embed = ConvEmbed(
            image_size=image_size,
            patch_size=patch_size,
            kernel_size=kernel_size,
            batch_size=batch_size,
            in_chans=in_chans,
            stride=patch_stride,
            padding=patch_padding,
            embed_dim=dim,
            norm_layer=norm_layer
        )
        self.patch_dim = int(dim) * 4 ** 2
        self.patch_to_embedding = nn.Linear(self.patch_dim, dim).to(device)

        # self.patch_to_embedding = nn.Linear(dim, dim).to(device)

        self.layers = nn.ModuleList([])
        for _ in range(depth):
            self.layers.append(nn.ModuleList([
                FeedForward(dim, mlp_dim, image_size, patch_size, kernel_size, dropout=dropout),
                # Residual(PreNorm(dim, FeedForward(dim, mlp_dim, image_size, patch_size, kernel_size, dropout=dropout))),
                # Residual(PreNorm(dim, PreForward(dim, dim, kernel_size, num_channels, dropout=dropout / 2))),
                Residual(PreNorm(dim, Attention(dim, image_size=image_size, patch_size=patch_size, heads=heads, dropout=dropout, kernel_size=kernel_size))),
            ]))
        self.dropout = nn.Dropout(dropout)
        self.norm = nn.LayerNorm(dim)
        self.patch_size = patch_size
        self.batch_size = batch_size
        self.head_num = heads

    def forward(self, img, adj):
        p = self.patch_size
        # x = rearrange(img, 'b c (h p1) (w p2) -> b (h w) (p1 p2 c)', p1=p, p2=p)
        # x = rearrange(x, 'b (s) (p1 p2 c) -> (b s) (c) (p1) (p2) ', p1=p, p2=p)

        x = rearrange(img, 'b c (h p1) (w p2) -> (b h w) (c) (p1) (p2)', p1=p, p2=p)

        conv_img = self.patch_embed(x)
        # b = self.batch_size
        conv_img = rearrange(conv_img, '(b s) c p1 p2 -> b s (c p1 p2)', s=int(img.size(2)/p)**2)

        # x = self.norm(x)
        x = self.patch_to_embedding(conv_img)

        b, n, _ = x.shape
        x = rearrange(x, 'b (h w) c -> b c h w', h=int(img.size(2)/p), w=int(img.size(2)/p))
        # x = F.tanh(x)
        # x = self.dropout(x)

        B, C, H, W = x.size()
        x = rearrange(x, 'b c h w -> b (h w) c')

        self.rep_adj = adj.expand(self.head_num, -1, -1).to(device)
        self.rep_adj = self.rep_adj.expand(b, -1, -1, -1).to(device)

        # for attn in self.layers:
        for pre, attn in self.layers:
        # for pre, attn, ff in self.layers:
            x = pre(x)
            x = attn(x, H, W, self.rep_adj)
            # x = ff(x)
            # x = pre(x)

        return x


class ViT(nn.Module):
    def __init__(self, *, image_size, patch_size, kernel_size, levels4tcn, batch_size, num_classes, dim, depth, heads,
                 mlp_dim, patch_stride, patch_pading, in_chans, dropout=0., emb_dropout=0., expansion_factor=1):
        super().__init__()
        assert image_size % patch_size == 0, 'image dimensions must be divisible by the patch size'
        pantchesalow = image_size // patch_size
        num_patches = pantchesalow ** 2

        self.adj_matrix = [[0 for i in range(num_patches)] for i in range(num_patches)]
        self.adj_matrix = torch.as_tensor(self.adj_matrix).float().to(device)

        for j in range(num_patches):
            if (j - pantchesalow -1) >= 0:
                self.adj_matrix[j][j - 1] = 1
                self.adj_matrix[j][j - pantchesalow] = 1
                self.adj_matrix[j][j - pantchesalow-1] = 1
                self.adj_matrix[j][j - pantchesalow+1] = 1
            if (j + pantchesalow+1) < num_patches:
                self.adj_matrix[j][j + 1] = 1
                self.adj_matrix[j][j + pantchesalow] = 1
                self.adj_matrix[j][j + pantchesalow-1] = 1
                self.adj_matrix[j][j + pantchesalow+1] = 1

        # patch_dim = channels * patch_size ** 2
        # assert num_patches > MIN_NUM_PATCHES, f'your number of patches ({num_patches}) is way too small for attention to be effective. try decreasing your patch size'

        self.patch_size = patch_size

        # self.pos_embedding = nn.Parameter(torch.randn(1, num_patches + 1, dim))
        # self.patch_to_embedding = nn.Linear(patch_dim, dim)
        # self.cls_token = nn.Parameter(torch.randn(1, 1, dim))
        self.dropout = nn.Dropout(emb_dropout)

        num_channels = [dim] * levels4tcn
        self.transformer = Transformer(dim, depth, heads, mlp_dim, dropout, image_size, patch_size, kernel_size, num_channels,
                                       batch_size, in_chans, patch_stride=patch_stride, patch_padding=patch_pading)

        self.to_cls_token = nn.Identity()

        # self.mlp_head = nn.Sequential(
        #     nn.LayerNorm(dim * expansion_factor),
        #     nn.Linear(dim * expansion_factor, mlp_dim),
        #     nn.GELU(),
        #     nn.Dropout(dropout),
        #     nn.Linear(mlp_dim, num_classes)
        # )
        self.mlp_head = nn.Sequential(
            nn.LayerNorm(dim),
            nn.Linear(dim, mlp_dim * expansion_factor),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(mlp_dim * expansion_factor, num_classes)
        )

    def forward_pre(self, img):
        self.adj_matrix = self.adj_matrix + torch.eye(self.adj_matrix.size(1)).to(device)  # :�*ӹ���
        x = self.transformer(img, self.adj_matrix)
        x = self.to_cls_token(x[:, -1])
        return x

    def forward_once(self, img):
        # p = self.patch_size
        # x = rearrange(img, 'b c (h p1) (w p2) -> b (h w) (p1 p2 c)', p1 = p, p2 = p)
        # x = self.patch_to_embedding(x)
        # x = self.dropout(x)
        x = self.forward_pre(img)
        x_f = self.mlp_head(x)
        return x_f

    def forward_class(self, img):
        # self.adj_matrix = self.adj_matrix + torch.eye(self.adj_matrix.size(1)).cuda(0)  # :�*ӹ���
        # x = self.transformer(img, self.adj_matrix)
        # # x = self.to_cls_token(x[:, 0])
        # x = self.to_cls_token(x.mean(dim=1))

        x = self.forward_pre(img)
        x_f = self.mlp_head(x)
        return x_f

    # def forward(self, input1, input2):
    #     output1 = self.forward_class(input1)
    #     output2 = self.forward_class(input2)
    #     output = output1
    #     return output1, output2, output
    def forward(self, input):
        output = self.forward_class(input)
        return output

